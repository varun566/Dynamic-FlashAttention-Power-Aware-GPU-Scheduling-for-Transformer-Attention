import json
import matplotlib.pyplot as plt
import numpy as np

def load_json(path):
    with open(path, "r") as f:
        return json.load(f)

# Load result files
baseline = load_json("../results/baseline_results.json")
flash = load_json("../results/flash_cuda_results.json")
custom = load_json("../results/custom_cuda_results.json")

seq_lengths = [512, 1024]

energy = {
    "Baseline CUDA": [],
    "FlashAttention CUDA": [],
    "Custom CUDA": []
}

def compute_energy(avg_power_w, latency_ms):
    return avg_power_w * (latency_ms / 1000.0)

# Fill energy values
for L in seq_lengths:

    # Baseline
    for entry in baseline:
        if entry["L"] == L:
            energy["Baseline CUDA"].append(
                compute_energy(entry["avg_power_watts"], entry["avg_latency_ms"])
            )

    # Flash
    for entry in flash:
        if entry["L"] == L:
            energy["FlashAttention CUDA"].append(
                compute_energy(entry["avg_power_watts"], entry["avg_latency_ms"])
            )

    # Custom — avoid duplicate entry for L=512
    seen = set()
    for entry in custom:
        if entry["L"] == L and L not in seen:
            energy["Custom CUDA"].append(
                compute_energy(entry["avg_power_watts"], entry["avg_latency_ms"])
            )
            seen.add(L)

# Plotting
x = np.arange(len(seq_lengths))
bar_width = 0.25

plt.figure(figsize=(10, 6))

plt.bar(x - bar_width, energy["Baseline CUDA"], width=bar_width, label="Baseline CUDA")
plt.bar(x, energy["FlashAttention CUDA"], width=bar_width, label="FlashAttention CUDA")
plt.bar(x + bar_width, energy["Custom CUDA"], width=bar_width, label="Custom CUDA Kernel")

plt.xticks(x, seq_lengths)
plt.xlabel("Sequence Length (L)")
plt.ylabel("Energy per Run (Joules)")
plt.title("Energy Consumption per Kernel Execution")
plt.grid(alpha=0.3)
plt.legend()

plt.savefig("energy_comparison.png", dpi=300)
print("Generated energy_comparison.png")
