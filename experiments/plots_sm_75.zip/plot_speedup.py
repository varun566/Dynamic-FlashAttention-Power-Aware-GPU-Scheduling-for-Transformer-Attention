import json
import matplotlib.pyplot as plt
import numpy as np

def load_json(path):
    with open(path, "r") as f:
        return json.load(f)

# Load all result files
baseline = load_json("../results/baseline_results.json")
flash = load_json("../results/flash_cuda_results.json")
custom = load_json("../results/custom_cuda_results.json")

seq_lengths = [512, 1024]

speedup = {
    "Baseline → Custom CUDA": [],
    "FlashAttention → Custom CUDA": []
}

# Helper: fetch latency for given list and L
def get_latency(data, L):
    seen = set()
    for entry in data:
        if entry["L"] == L and L not in seen:
            seen.add(L)
            return entry["avg_latency_ms"]
    return None

# Compute speedups
for L in seq_lengths:
    t_base = get_latency(baseline, L)
    t_flash = get_latency(flash, L)
    t_custom = get_latency(custom, L)

    speedup["Baseline → Custom CUDA"].append(t_base / t_custom)
    speedup["FlashAttention → Custom CUDA"].append(t_flash / t_custom)

# Plotting setup
x = np.arange(len(seq_lengths))
bar_width = 0.35

plt.figure(figsize=(10, 6))

# Bars
plt.bar(x - bar_width/2, speedup["Baseline → Custom CUDA"], 
        width=bar_width, label="Baseline → Custom CUDA")
plt.bar(x + bar_width/2, speedup["FlashAttention → Custom CUDA"],
        width=bar_width, label="FlashAttention → Custom CUDA")

# Labels
plt.xticks(x, seq_lengths)
plt.xlabel("Sequence Length (L)")
plt.ylabel("Speedup (×)")
plt.title("Speedup of Custom CUDA Kernel Over Baseline and FlashAttention")
plt.grid(alpha=0.3)
plt.legend()

plt.savefig("speedup_plot.png", dpi=300)
print("Generated speedup_plot.png")
